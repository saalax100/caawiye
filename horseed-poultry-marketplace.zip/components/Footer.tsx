
import React from 'react';

const Footer: React.FC = () => {
  return (
    <footer className="w-full border-t border-slate-200 dark:border-[#4a4a21] bg-white dark:bg-background-dark py-12 px-4 md:px-10 transition-colors">
      <div className="max-w-[1440px] mx-auto grid grid-cols-1 md:grid-cols-4 gap-12">
        <div className="flex flex-col gap-4">
          <div className="flex items-center gap-2 text-primary">
            <span className="material-symbols-outlined text-3xl">agriculture</span>
            <h2 className="text-slate-900 dark:text-white text-xl font-bold">Horseed</h2>
          </div>
          <p className="text-slate-500 dark:text-[#cccc8e] text-sm leading-relaxed">
            The leading digital marketplace for premium poultry products. Connect directly with farmers for the freshest supply.
          </p>
        </div>
        
        <div className="flex flex-col gap-4">
          <h4 className="text-slate-900 dark:text-white font-bold uppercase tracking-widest text-xs">Marketplace</h4>
          <div className="flex flex-col gap-2">
            <a className="text-slate-500 dark:text-slate-400 text-sm hover:text-primary transition-colors" href="#">Live Poultry</a>
            <a className="text-slate-500 dark:text-slate-400 text-sm hover:text-primary transition-colors" href="#">Eggs & Produce</a>
            <a className="text-slate-500 dark:text-slate-400 text-sm hover:text-primary transition-colors" href="#">Farming Feed</a>
            <a className="text-slate-500 dark:text-slate-400 text-sm hover:text-primary transition-colors" href="#">Vet Supplies</a>
          </div>
        </div>
        
        <div className="flex flex-col gap-4">
          <h4 className="text-slate-900 dark:text-white font-bold uppercase tracking-widest text-xs">Account</h4>
          <div className="flex flex-col gap-2">
            <a className="text-slate-500 dark:text-slate-400 text-sm hover:text-primary transition-colors" href="#">Login</a>
            <a className="text-slate-500 dark:text-slate-400 text-sm hover:text-primary transition-colors" href="#">Register as Farmer</a>
            <a className="text-slate-500 dark:text-slate-400 text-sm hover:text-primary transition-colors" href="#">My Orders</a>
            <a className="text-slate-500 dark:text-slate-400 text-sm hover:text-primary transition-colors" href="#">Wishlist</a>
          </div>
        </div>
        
        <div className="flex flex-col gap-4">
          <h4 className="text-slate-900 dark:text-white font-bold uppercase tracking-widest text-xs">Newsletter</h4>
          <p className="text-slate-500 dark:text-slate-400 text-sm">Subscribe for daily prices & updates.</p>
          <div className="flex h-10 overflow-hidden rounded-lg shadow-sm">
            <input 
              className="flex-1 bg-slate-100 dark:bg-[#4a4a21] border-none text-sm px-4 focus:ring-0 text-slate-900 dark:text-white" 
              placeholder="Email address" 
              type="email"
            />
            <button className="bg-primary px-4 text-slate-900 font-bold text-xs uppercase hover:brightness-110 transition-all">Join</button>
          </div>
        </div>
      </div>
      
      <div className="max-w-[1440px] mx-auto mt-12 pt-8 border-t border-slate-100 dark:border-[#4a4a21] text-center">
        <p className="text-slate-400 text-xs">© 2024 Horseed Marketplace. All rights reserved. Distributed by FarmNetwork.</p>
      </div>
    </footer>
  );
};

export default Footer;
