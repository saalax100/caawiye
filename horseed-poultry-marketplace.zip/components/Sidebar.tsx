
import React from 'react';
import { Category, FilterState } from '../types';

interface SidebarProps {
  filters: FilterState;
  onCategorySelect: (category: Category) => void;
  onPriceChange: (range: [number, number]) => void;
  onToggleAvailability: (type: 'inStock' | 'preOrder') => void;
}

const Sidebar: React.FC<SidebarProps> = ({ filters, onCategorySelect, onPriceChange, onToggleAvailability }) => {
  const categories = [
    { name: Category.ALL, icon: 'grid_view' },
    { name: Category.EGGS, icon: 'egg' },
    { name: Category.CHICKS, icon: 'nest_cam_indoor' },
    { name: Category.BROILERS, icon: 'bakery_dining' },
    { name: Category.FEED, icon: 'grain' },
  ];

  return (
    <aside className="w-full md:w-64 flex-shrink-0 flex flex-col gap-6">
      <div className="flex flex-col gap-2">
        <div className="flex flex-wrap gap-2 text-sm mb-4">
          <a className="text-slate-400 dark:text-[#cccc8e] font-medium" href="#">Home</a>
          <span className="text-slate-400 dark:text-[#cccc8e]">/</span>
          <span className="text-slate-900 dark:text-white font-medium">Marketplace</span>
        </div>
      </div>
      
      <div className="bg-white dark:bg-background-dark border border-slate-200 dark:border-[#4a4a21] rounded-xl p-6 flex flex-col gap-8 sticky top-24 transition-colors">
        <div className="flex flex-col gap-4">
          <h1 className="text-slate-900 dark:text-white text-lg font-bold">Categories</h1>
          <div className="flex flex-col gap-1">
            {categories.map((cat) => (
              <div 
                key={cat.name}
                onClick={() => onCategorySelect(cat.name)}
                className={`flex items-center gap-3 px-3 py-2 rounded-lg cursor-pointer transition-all ${
                  filters.category === cat.name 
                    ? 'bg-primary/10 dark:bg-[#4a4a21] text-primary font-bold' 
                    : 'text-slate-600 dark:text-white hover:bg-slate-50 dark:hover:bg-white/5'
                }`}
              >
                <span className="material-symbols-outlined">{cat.icon}</span>
                <p className="text-sm font-medium">{cat.name}</p>
              </div>
            ))}
          </div>
        </div>
        
        <div className="flex flex-col gap-4">
          <p className="text-slate-900 dark:text-white text-base font-bold">Price Range</p>
          <div className="flex flex-col gap-6 pt-2">
             {/* Simplified range UI since standard input type range is hard to style as dual-handle */}
            <div className="flex flex-col gap-4">
              <input 
                type="range" 
                min="0" 
                max="500" 
                value={filters.priceRange[1]} 
                onChange={(e) => onPriceChange([10, parseInt(e.target.value)])}
                className="w-full accent-primary h-1.5 bg-slate-200 dark:bg-[#4a4a21] rounded-full appearance-none cursor-pointer"
              />
              <div className="flex justify-between text-xs font-bold text-slate-900 dark:text-white">
                <span>$10</span>
                <span>Max: ${filters.priceRange[1]}</span>
              </div>
            </div>
          </div>
        </div>
        
        <div className="flex flex-col gap-4">
          <p className="text-slate-900 dark:text-white text-base font-bold">Availability</p>
          <div className="flex flex-col gap-3">
            <label className="flex items-center gap-3 cursor-pointer group">
              <div 
                onClick={() => onToggleAvailability('inStock')}
                className="size-5 rounded border-2 border-slate-300 dark:border-[#4a4a21] flex items-center justify-center group-hover:border-primary transition-colors"
              >
                {filters.availability.inStock && <div className="size-2.5 bg-primary rounded-sm"></div>}
              </div>
              <span className="text-sm text-slate-600 dark:text-white">In Stock</span>
            </label>
            <label className="flex items-center gap-3 cursor-pointer group">
              <div 
                onClick={() => onToggleAvailability('preOrder')}
                className="size-5 rounded border-2 border-slate-300 dark:border-[#4a4a21] flex items-center justify-center group-hover:border-primary transition-colors"
              >
                {filters.availability.preOrder && <div className="size-2.5 bg-primary rounded-sm"></div>}
              </div>
              <span className="text-sm text-slate-600 dark:text-white">Pre-order</span>
            </label>
          </div>
        </div>
        
        <button className="w-full bg-primary text-slate-900 py-3 rounded-lg font-bold text-sm hover:brightness-110 transition-all shadow-lg shadow-primary/20">
          Apply Filters
        </button>
      </div>
    </aside>
  );
};

export default Sidebar;
