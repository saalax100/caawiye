
import React from 'react';
import { Product } from '../types';

interface ProductGridProps {
  products: Product[];
}

const ProductGrid: React.FC<ProductGridProps> = ({ products }) => {
  return (
    <div className="flex flex-col gap-8">
      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-6">
        {products.map((product) => (
          <div 
            key={product.id}
            className="flex flex-col bg-white dark:bg-background-dark border border-slate-200 dark:border-[#4a4a21] rounded-xl overflow-hidden group hover:shadow-xl hover:shadow-primary/5 transition-all duration-300"
          >
            <div className="aspect-[4/3] w-full bg-slate-100 relative overflow-hidden">
              {product.badge && (
                <div className={`absolute top-3 left-3 z-10 text-slate-900 text-[10px] font-black uppercase px-2 py-1 rounded ${
                  product.badge === 'Bestseller' ? 'bg-primary' : 'bg-white'
                }`}>
                  {product.badge}
                </div>
              )}
              <img 
                className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-500" 
                src={product.image} 
                alt={product.name} 
              />
            </div>
            <div className="p-5 flex flex-col gap-4">
              <div className="flex flex-col gap-1">
                <h3 className="text-slate-900 dark:text-white font-bold text-lg line-clamp-1">{product.name}</h3>
                <p className="text-slate-500 dark:text-slate-400 text-xs">{product.minOrder}</p>
              </div>
              <div className="flex items-center justify-between">
                <div className="flex flex-col">
                  <span className="text-primary font-black text-2xl">${product.price.toFixed(2)}</span>
                  <span className="text-[10px] text-slate-400 uppercase font-bold tracking-wider">{product.unit}</span>
                </div>
                <button className="bg-primary hover:bg-primary/90 text-slate-900 size-11 rounded-lg flex items-center justify-center transition-colors shadow-sm">
                  <span className="material-symbols-outlined">add_shopping_cart</span>
                </button>
              </div>
            </div>
          </div>
        ))}
      </div>
      
      {products.length === 0 && (
        <div className="flex flex-col items-center justify-center py-20 text-center">
          <span className="material-symbols-outlined text-6xl text-slate-300 dark:text-[#4a4a21] mb-4">search_off</span>
          <h3 className="text-xl font-bold dark:text-white">No products found</h3>
          <p className="text-slate-500 dark:text-[#cccc8e]">Try adjusting your filters or search query.</p>
        </div>
      )}

      {products.length > 0 && (
        <div className="flex items-center justify-center gap-2 py-10">
          <button className="flex items-center justify-center size-10 rounded-lg border border-slate-200 dark:border-[#4a4a21] text-slate-400 hover:text-primary transition-colors">
            <span className="material-symbols-outlined">chevron_left</span>
          </button>
          <button className="size-10 rounded-lg bg-primary text-slate-900 font-bold">1</button>
          <button className="size-10 rounded-lg hover:bg-slate-100 dark:hover:bg-[#4a4a21] text-slate-600 dark:text-white font-bold transition-colors">2</button>
          <button className="size-10 rounded-lg hover:bg-slate-100 dark:hover:bg-[#4a4a21] text-slate-600 dark:text-white font-bold transition-colors">3</button>
          <span className="px-2 text-slate-400">...</span>
          <button className="size-10 rounded-lg hover:bg-slate-100 dark:hover:bg-[#4a4a21] text-slate-600 dark:text-white font-bold transition-colors">12</button>
          <button className="flex items-center justify-center size-10 rounded-lg border border-slate-200 dark:border-[#4a4a21] text-slate-400 hover:text-primary transition-colors">
            <span className="material-symbols-outlined">chevron_right</span>
          </button>
        </div>
      )}
    </div>
  );
};

export default ProductGrid;
