
import React, { useState, useRef, useEffect } from 'react';
import { GoogleGenAI } from '@google/genai';

const GeminiAssistant: React.FC = () => {
  const [isOpen, setIsOpen] = useState(false);
  const [messages, setMessages] = useState<{ role: 'user' | 'bot'; text: string }[]>([]);
  const [input, setInput] = useState('');
  const [isTyping, setIsTyping] = useState(false);
  const messagesEndRef = useRef<HTMLDivElement>(null);

  const scrollToBottom = () => {
    messagesEndRef.current?.scrollIntoView({ behavior: "smooth" });
  };

  useEffect(() => {
    scrollToBottom();
  }, [messages]);

  const handleSend = async () => {
    if (!input.trim()) return;

    const userMsg = input.trim();
    setInput('');
    setMessages(prev => [...prev, { role: 'user', text: userMsg }]);
    setIsTyping(true);

    try {
      const ai = new GoogleGenAI({ apiKey: process.env.API_KEY || '' });
      const response = await ai.models.generateContent({
        model: 'gemini-3-flash-preview',
        contents: userMsg,
        config: {
          systemInstruction: 'You are an expert poultry farming assistant for the Horseed Marketplace. Help users with poultry care, egg quality questions, feed advice, and finding the right products on Horseed. Keep answers helpful, agricultural, and concise.',
        },
      });

      const botText = response.text || "I'm sorry, I couldn't process that. Please try again.";
      setMessages(prev => [...prev, { role: 'bot', text: botText }]);
    } catch (error) {
      console.error('Gemini error:', error);
      setMessages(prev => [...prev, { role: 'bot', text: "There was an error connecting to my farm brain. Please check your connection." }]);
    } finally {
      setIsTyping(false);
    }
  };

  return (
    <div className="fixed bottom-6 right-6 z-[100]">
      {isOpen ? (
        <div className="w-80 md:w-96 h-[500px] bg-white dark:bg-[#2c2c13] rounded-2xl shadow-2xl flex flex-col overflow-hidden border border-slate-200 dark:border-[#4a4a21] animate-in slide-in-from-bottom-4 duration-300">
          <div className="bg-primary p-4 flex items-center justify-between">
            <div className="flex items-center gap-2">
              <span className="material-symbols-outlined text-slate-900">smart_toy</span>
              <h3 className="font-black text-slate-900 uppercase text-sm tracking-widest">Horseed AI Helper</h3>
            </div>
            <button onClick={() => setIsOpen(false)} className="text-slate-900 hover:scale-110 transition-all">
              <span className="material-symbols-outlined">close</span>
            </button>
          </div>
          
          <div className="flex-1 overflow-y-auto p-4 flex flex-col gap-4">
            {messages.length === 0 && (
              <div className="text-center py-10">
                <p className="text-slate-500 dark:text-[#cccc8e] text-sm">Ask me about poultry care, feed ratios, or finding products!</p>
              </div>
            )}
            {messages.map((msg, idx) => (
              <div key={idx} className={`flex ${msg.role === 'user' ? 'justify-end' : 'justify-start'}`}>
                <div className={`max-w-[85%] p-3 rounded-2xl text-sm ${
                  msg.role === 'user' 
                    ? 'bg-primary text-slate-900 rounded-tr-none' 
                    : 'bg-slate-100 dark:bg-[#4a4a21] text-slate-800 dark:text-white rounded-tl-none'
                }`}>
                  {msg.text}
                </div>
              </div>
            ))}
            {isTyping && (
              <div className="flex justify-start">
                <div className="bg-slate-100 dark:bg-[#4a4a21] p-3 rounded-2xl rounded-tl-none">
                  <div className="flex gap-1">
                    <div className="w-1.5 h-1.5 bg-slate-400 rounded-full animate-bounce"></div>
                    <div className="w-1.5 h-1.5 bg-slate-400 rounded-full animate-bounce [animation-delay:-0.15s]"></div>
                    <div className="w-1.5 h-1.5 bg-slate-400 rounded-full animate-bounce [animation-delay:-0.3s]"></div>
                  </div>
                </div>
              </div>
            )}
            <div ref={messagesEndRef} />
          </div>
          
          <div className="p-4 border-t border-slate-100 dark:border-[#4a4a21]">
            <div className="flex gap-2">
              <input 
                type="text" 
                value={input}
                onChange={(e) => setInput(e.target.value)}
                onKeyDown={(e) => e.key === 'Enter' && handleSend()}
                placeholder="Type your message..."
                className="flex-1 bg-slate-100 dark:bg-[#4a4a21] border-none rounded-lg text-sm px-4 focus:ring-0 dark:text-white"
              />
              <button 
                onClick={handleSend}
                disabled={isTyping || !input.trim()}
                className="bg-primary text-slate-900 size-10 rounded-lg flex items-center justify-center disabled:opacity-50 transition-all hover:scale-105"
              >
                <span className="material-symbols-outlined">send</span>
              </button>
            </div>
          </div>
        </div>
      ) : (
        <button 
          onClick={() => setIsOpen(true)}
          className="size-16 bg-primary rounded-full shadow-xl flex items-center justify-center text-slate-900 hover:scale-110 transition-all group"
        >
          <span className="material-symbols-outlined text-3xl group-hover:rotate-12 transition-all">smart_toy</span>
          <div className="absolute -top-1 -right-1 size-4 bg-red-500 rounded-full border-2 border-white"></div>
        </button>
      )}
    </div>
  );
};

export default GeminiAssistant;
