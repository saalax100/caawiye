
import React from 'react';

interface HeaderProps {
  onSearch: (query: string) => void;
  darkMode: boolean;
  toggleDarkMode: () => void;
}

const Header: React.FC<HeaderProps> = ({ onSearch, darkMode, toggleDarkMode }) => {
  return (
    <header className="sticky top-0 z-50 w-full border-b border-solid border-slate-200 dark:border-[#4a4a21] bg-white dark:bg-background-dark px-4 md:px-10 py-3 transition-colors">
      <div className="max-w-[1440px] mx-auto flex items-center justify-between gap-4">
        <div className="flex items-center gap-8">
          <div className="flex items-center gap-2 text-primary cursor-pointer" onClick={() => window.location.reload()}>
            <div className="size-8 flex items-center justify-center">
              <span className="material-symbols-outlined text-3xl">agriculture</span>
            </div>
            <h2 className="text-slate-900 dark:text-white text-xl font-bold leading-tight tracking-[-0.015em]">Horseed</h2>
          </div>
          <div className="hidden lg:flex items-center gap-6">
            <a className="text-slate-600 dark:text-white text-sm font-medium hover:text-primary transition-colors" href="#">Marketplace</a>
            <a className="text-slate-600 dark:text-white text-sm font-medium hover:text-primary transition-colors" href="#">Feed</a>
            <a className="text-slate-600 dark:text-white text-sm font-medium hover:text-primary transition-colors" href="#">Equipments</a>
            <a className="text-slate-600 dark:text-white text-sm font-medium hover:text-primary transition-colors" href="#">About Us</a>
          </div>
        </div>
        
        <div className="flex flex-1 max-w-md items-center gap-4">
          <label className="flex flex-col flex-1 h-10">
            <div className="flex w-full flex-1 items-stretch rounded-lg h-full overflow-hidden">
              <div className="text-slate-400 dark:text-[#cccc8e] flex border-none bg-slate-100 dark:bg-[#4a4a21] items-center justify-center pl-4">
                <span className="material-symbols-outlined text-xl">search</span>
              </div>
              <input 
                className="form-input flex w-full border-none bg-slate-100 dark:bg-[#4a4a21] text-slate-900 dark:text-white focus:outline-0 focus:ring-0 h-full placeholder:text-slate-400 dark:placeholder:text-[#cccc8e] px-4 pl-2 text-base font-normal" 
                placeholder="Search poultry, eggs..." 
                onChange={(e) => onSearch(e.target.value)}
              />
            </div>
          </label>
        </div>
        
        <div className="flex items-center gap-2 md:gap-4">
          <button 
            onClick={toggleDarkMode}
            className="flex items-center justify-center rounded-lg size-10 bg-slate-100 dark:bg-[#4a4a21] text-slate-700 dark:text-white hover:bg-primary/20 transition-all"
          >
            <span className="material-symbols-outlined">{darkMode ? 'light_mode' : 'dark_mode'}</span>
          </button>
          <button className="flex items-center justify-center rounded-lg size-10 bg-slate-100 dark:bg-[#4a4a21] text-slate-700 dark:text-white hover:bg-primary/20 transition-all">
            <span className="material-symbols-outlined">shopping_cart</span>
          </button>
          <button className="flex items-center justify-center rounded-lg size-10 bg-slate-100 dark:bg-[#4a4a21] text-slate-700 dark:text-white hover:bg-primary/20 transition-all">
            <span className="material-symbols-outlined">account_circle</span>
          </button>
          <div 
            className="hidden sm:block bg-center bg-no-repeat aspect-square bg-cover rounded-full size-10 border-2 border-primary" 
            style={{backgroundImage: 'url("https://lh3.googleusercontent.com/aida-public/AB6AXuBpZX5aVWntt8HC6E0EyPM8ZgSNf9Ag_3G4Pif_MNbLG_bdYQKdpzemPgocHqQI1p4EqziJlJMfiVKXhh5UhuN0TbC4Cs7tTDLK_ldGMWeOL0TCmHtzrQUodf7y_NuXz1WDjily9jI2EhG0hzOvPAkd6ZAl3M9iu92L-S2L9JVT1xX58unrwWrKmWCI1K0tA8FhlodSXGd1YpBblx00eR-z9CYOzmIu6_16SMFSdwb2zsV0UgQY6KU-2hB-rNXDX0fn4a0p2rphSZo")'}}
          ></div>
        </div>
      </div>
    </header>
  );
};

export default Header;
